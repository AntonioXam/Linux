#!/bin/bash

more /etc/group | cut -d":" -f1
