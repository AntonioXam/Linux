#!/bin/bash

echo -n "Introduce un numero: "
read var

while [ $var -ne 0 ]; do
echo -n "Introduce un numero: "
read var

done

