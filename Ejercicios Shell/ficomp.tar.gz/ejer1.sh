#!/bin/bash

echo "Usuario conectados"
who

echo "Directorio actual"
pwd

echo "Fecha actual"
date
